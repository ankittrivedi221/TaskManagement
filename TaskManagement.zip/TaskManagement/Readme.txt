This is a sample Java / Maven / Spring Boot (version 2.6.3) application that can be used as a starter for creating Task Management System.

About System.

The service is just a simple hotel review REST service. It uses an in-memory database (H2) to store the data. You can also do with a relational database like MySQL or PostgreSQL. If your database connection properties work, you can call some REST endpoints defined in com.task.controller.TaskController on port 8083. (see below)


You can use this sample service to understand the conventions and configurations that allow you to create a DB-backed RESTful service. Once you understand and get comfortable with the sample app you can add your own services following the same patterns as the sample service.

Here is what this little application demonstrates:

->Full integration with the latest Spring Framework: inversion of control, dependency injection, etc.
->Writing a RESTful service using annotation: supports JSON request / response; simply use desired Accept header in your request
->Exception mapping from application exceptions to the right HTTP response with exception details in the body
Spring Data Integration with JPA/Hibernate with just a few lines of configuration and familiar annotations.
->Automatic CRUD functionality against the data source using Spring Repository pattern
->All APIs are "self-documented" by Swagger3 using annotations

Here are some endpoints you can call:

Get information about Task Management, configurations, etc.
http://localhost:8083/task
http://localhost:8083/task/add-task
http://localhost:8083/task/modify-task/{taskId}
http://localhost:8083/task/add-subtask/{taskId}
http://localhost:8083/task/delete-task/{taskId}
http://localhost:8083/task/remove-subtask/{taskId}
http://localhost:8083/task/modify-subtask/{taskId}
