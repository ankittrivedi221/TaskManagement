package com.task;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;

import com.task.entity.Task;
import com.task.repo.TaskRepo;
import com.task.service.TaskService;

@SpringBootTest
@TestInstance(Lifecycle.PER_CLASS)
class TaskManagementApplicationTests {

	@Autowired
	TaskService service;
	@Autowired
	TaskRepo taskRepo;

	Task task = new Task();

	@BeforeAll
	void init() {

		// task.setTaskId(1L);
		task.setName("Java");
		task.setGroupId(1);
		task.setDescription("Java Testing");
		task.setStatusId(2);
		task.setAssingedId(0);
		// task.setSubTasks("Java Sub Task");
		task.setTimeSpent(new Date());

		task.setParentTaskId(0);
		task = taskRepo.save(task);

		System.out.println(task.getId());
	}

	@Test
	void contextLoads() {

	}

	@Test
	void getAllTask() {
		List<Task> response = service.getAllTask(0L,"Java","Java Testing",0,0,0);
		assertTrue(response != null);
	}

	@Test
	void addTask() {
		Task newTask = new Task();
		newTask.setName("Java");                
		newTask.setGroupId(1);                  
		newTask.setDescription("Java Testing"); 
		newTask.setStatusId(2); 
		newTask.setAssingedId(0);
		newTask.setParentTaskId(0);
		newTask.setTimeSpent(new Date());

		ResponseEntity<?> responseTask = service.addTask(newTask);
		assertTrue(responseTask != null);

	}

	@Test
	void editTask() {
		Task newTask = new Task();
		newTask.setName("Java");                
		newTask.setGroupId(1);                  
		newTask.setDescription("Java Testing"); 
		newTask.setStatusId(2); 
		newTask.setAssingedId(0);
		newTask.setParentTaskId(0);
		newTask.setTimeSpent(new Date());

		ResponseEntity<?> responseTask = service.addTask(newTask);
		assertTrue(responseTask != null);

	}

	@Test
	void removeTask() {

		ResponseEntity<?> responseEntity = service.removeTask(1L);
		assertTrue(responseEntity != null);
	}

	
}
