package com.task.controllar;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.task.entity.Task;
import com.task.service.TaskService;

@RestController
@RequestMapping("/tasks")
public class TaskController {

	@Autowired
	TaskService service;

	@GetMapping
	public List<Task> getAll(@RequestParam(name = "id", required = false, defaultValue = "0") Long id,
			@RequestParam(name = "name", required = false, defaultValue = "") String name,
			@RequestParam(name = "description", required = false, defaultValue = "") String description,
			@RequestParam(name = "groupId", required = false, defaultValue = "0") Integer groupId,

			@RequestParam(name = "statusId", required = false, defaultValue = "0") Integer statusId,
			@RequestParam(name = "assignedId", required = false, defaultValue = "0") Integer assignedId) {

		return service.getAllTask(id, name, description, groupId, assignedId, statusId);
	}

	@PostMapping
	public ResponseEntity<?> addTask(@RequestBody Task task) {
		if (task.getName().isEmpty() || task.getDescription().isEmpty()) {
			return new ResponseEntity<>("Please Enter All the Fields", HttpStatus.BAD_REQUEST);
		}

		return service.addTask(task);
	}

	@PutMapping("/{id}")
	public ResponseEntity<?> editTaskDetails(@PathVariable(name = "id") Long id, @RequestBody Task task) {

		if (task.getName().isEmpty() || task.getDescription().isEmpty()) {
			return new ResponseEntity<>("Please Enter All the Fields", HttpStatus.BAD_REQUEST);
		}
		task.setId(id);
		return service.addTask(task);

	}

	@PutMapping("/assignee/{id}")
	public ResponseEntity<?> addAssignee(@PathVariable(name = "id") Long id,
			@RequestParam(name = "assingedId", required = false, defaultValue = "0") Integer assingedId) {

		return service.addAssignee(id, assingedId);

	}

	@DeleteMapping("/{id}")
	public ResponseEntity<?> removeTask(@PathVariable(name = "id") Long id) {
		return service.removeTask(id);
	}

}
