package com.task.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "Task")
public class Task {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;
	@Column(name = "name")
	private String name;
	@Column(name = "description", nullable = true)
	private String description;
	@Column(name = "groupId")
	private Integer groupId;
	@Column(name = "statusId")
	private Integer statusId;
	@Column(name = "assignedId")
	private Integer assingedId = 0;
	@JsonFormat(pattern = "hh:mm:ss")
	@Column(name = "timeSpent", nullable = true)
	@Temporal(TemporalType.TIMESTAMP)
	private Date timeSpent;
	@Column(name = "parentTaskId")
	private Integer parentTaskId = 0;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getGroupId() {
		return groupId;
	}

	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}

	public int getStatusId() {
		return statusId;
	}

	public void setStatusId(int statusId) {
		this.statusId = statusId;
	}

	public Integer getAssingedId() {
		return assingedId;
	}

	public void setAssingedId(Integer assingedId) {
		this.assingedId = assingedId;
	}

	public Date getTimeSpent() {
		return timeSpent;
	}

	public void setTimeSpent(Date timeSpent) {
		this.timeSpent = timeSpent;
	}

	public Integer getParentTaskId() {
		return parentTaskId;
	}

	public void setParentTaskId(Integer parentTaskId) {
		this.parentTaskId = parentTaskId;
	}

}
