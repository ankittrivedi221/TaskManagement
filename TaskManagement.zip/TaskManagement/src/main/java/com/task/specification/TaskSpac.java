package com.task.specification;

import org.springframework.data.jpa.domain.Specification;

import com.task.entity.Task;

public class TaskSpac {

	public static Specification<Task> getSpac(Long id, String name, String description, Integer groupId,
			Integer statusId, Integer assignedId) {

		Specification<Task> spac = null;
		Specification<Task> temp = null;
		if (id != 0) {
			spac = getId(id);
			temp = spac != null ? Specification.where(spac).and(temp) : temp;
		}
		if (!name.isEmpty() && name != null) {
			spac = getNane(name);
			temp = spac != null ? Specification.where(spac).and(temp) : temp;
		}
		if (!description.isEmpty() && description != null) {
			spac = getDes(description);
			temp = spac != null ? Specification.where(spac).and(temp) : temp;
		}
		if (groupId != 0) {
			spac = getGro(groupId);
			temp = spac != null ? Specification.where(spac).and(temp) : temp;
		}
		if (statusId != 0) {
			spac = getSts(statusId);
			temp = spac != null ? Specification.where(spac).and(temp) : temp;
		}
		if (assignedId != 0) {
			spac = getAss(assignedId);
			temp = spac != null ? Specification.where(spac).and(temp) : temp;
		}

		return spac;
	}

	private static Specification<Task> getId(Long id) {
		return (root, query, CriteriaBuilder) -> {
			return CriteriaBuilder.equal(root.get("id"), id);

		};
	}

	private static Specification<Task> getNane(String name) {
		return (root, query, CriteriaBuilder) -> {
			return CriteriaBuilder.like(CriteriaBuilder.lower(root.get("name")), "%" + name.toLowerCase() + "%");
		};
	}

	private static Specification<Task> getDes(String description) {
		return (root, query, CriteriaBuilder) -> {
			return CriteriaBuilder.like(CriteriaBuilder.lower(root.get("description")),
					"%" + description.toLowerCase() + "%");

		};
	}

	private static Specification<Task> getGro(Integer groupId) {
		return (root, query, CriteriaBuilder) -> {
			return CriteriaBuilder.equal(root.get("groupId"), groupId);

		};
	}

	private static Specification<Task> getSts(Integer statusId) {
		return (root, query, CriteriaBuilder) -> {
			return CriteriaBuilder.equal(root.get("statusId"), statusId);
		};
	}

	private static Specification<Task> getAss(Integer assignedId) {
		return (root, query, CriteriaBuilder) -> {
			return CriteriaBuilder.equal(root.get("assignedId"), assignedId);
		};
	}
}
