package com.task.repo;

import java.util.List;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.task.entity.Task;

//@Repository
public interface TaskRepo extends JpaRepository<Task, Long> {
	@Query("select t from Task t where t.id=:id")
	Task findByIds(@Param("id") Long id);
	List<Task> findByNameAndGroupId(String name,Integer groupId);


	@Query("select t from Task t where  t.name=:name and t.groupId=:groupId")
	List<Task> serch(@Param("name") String name,@Param("groupId") Integer groupId); 
	
	
	List<Task> findAll(Specification<Task> spec); 
}
