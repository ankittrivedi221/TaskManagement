package com.task.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.task.entity.Task;
import com.task.repo.TaskRepo;
import com.task.specification.TaskSpac;

@Service
public class TaskServiceImpl implements TaskService {

	@Autowired
	TaskRepo taskRepo;

	@Override
	public List<Task> getAllTask(Long id, String name, String description, Integer groupId, Integer assignedId,
			Integer statusId) {
		if (!name.isEmpty() || !description.isEmpty() || groupId != 0 || statusId != 0 || assignedId != 0 || id != 0) {
			Specification<Task> spac = TaskSpac.getSpac(id,name, description, groupId, statusId, assignedId);
			return taskRepo.findAll(spac);
		}
		// TODO Auto-generated method stub
		return taskRepo.findAll();
	}

	@Override
	public ResponseEntity<?> addTask(Task task) {
		// TODO Auto-generated method stub
		Task tasks = new Task(); // Integer parentId = task.getParentTaskId();

		if (task.getParentTaskId() != 0) {
			tasks = taskRepo.findByIds(Long.parseLong(task.getParentTaskId().toString()));
		}
		try {
			if (tasks == null) {
				return new ResponseEntity<>("You should not enter sub task before creating Task",
						HttpStatus.BAD_REQUEST);
			} else {

				task.setTimeSpent(new Date());
				return new ResponseEntity<>(taskRepo.save(task), HttpStatus.OK);

			}

		} catch (Exception e) {

			e.printStackTrace();

		}

		return null;

	}

	@Override
	public ResponseEntity<?> removeTask(Long id) {
		// TODO Auto-generated method stub
		Optional<Task> tasks = taskRepo.findById(id);
		// Task task = tasks.get();
		if (!tasks.isEmpty()) {

			Task task = tasks.get();
			// List<Task> taskList = taskRepo.findBySubTasks(task.getName());

			// if (taskList.isEmpty()) {

			taskRepo.deleteById(task.getId());
			return new ResponseEntity<>("Task is Deleted", HttpStatus.OK);
			// }

		}
		return new ResponseEntity<>("First Remove sub task of Task", HttpStatus.BAD_REQUEST);

	}

	@Override
	public ResponseEntity<?> addAssignee(Long id, Integer assignedId) {
		// TODO Auto-generated method stub

		Task task = taskRepo.findByIds(id);
		task.setAssingedId(assignedId);
		task = taskRepo.save(task);
		return new ResponseEntity<>(task, HttpStatus.OK);

	}

}
