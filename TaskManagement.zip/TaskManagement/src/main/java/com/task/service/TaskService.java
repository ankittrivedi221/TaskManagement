package com.task.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.task.entity.Task;

public interface TaskService {

	public List<Task> getAllTask(Long id,String name,String description,Integer groupId,Integer assignedId,Integer statusId);

	public ResponseEntity<?> addTask(Task task);
	
	public ResponseEntity<?> addAssignee(Long id,Integer assignedId); 

	public ResponseEntity<?> removeTask(Long taskId);

	
	
	

}
